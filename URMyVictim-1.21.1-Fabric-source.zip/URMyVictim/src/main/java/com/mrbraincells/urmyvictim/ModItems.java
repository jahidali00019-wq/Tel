package com.mrbraincells.urmyvictim;

import com.mrbraincells.urmyvictim.item.*;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    public static final Item GRAPES = reg("grapes", new Item(new Item.Settings().food(
        new FoodComponent.Builder().nutrition(2).saturationModifier(0.3f).build())));
    public static final Item GRAPE_SEEDS = reg("grape_seeds", new BlockItem(ModBlocks.GRAPE_CROP, new Item.Settings()));
    public static final Item TOBACCO_SEEDS = reg("tobacco_seeds", new BlockItem(ModBlocks.TOBACCO_CROP, new Item.Settings()));
    public static final Item TOBACCO_LEAF = reg("tobacco_leaf", new Item(new Item.Settings()));
    public static final Item DRIED_TOBACCO_LEAF = reg("dried_tobacco_leaf", new Item(new Item.Settings()));

    // Drinking / smoking makes you drunk
    public static final Item DESHI_WINE = reg("deshi_wine", new DeshiWineItem(new Item.Settings().maxCount(16).food(
        new FoodComponent.Builder().nutrition(0).saturationModifier(0f).alwaysEdible()
            .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 700, 0), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 500, 1), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 500, 0), 1f)
            .build())));
    public static final Item CIGARETTE = reg("cigarette", new CigaretteItem(new Item.Settings().maxCount(32).food(
        new FoodComponent.Builder().nutrition(0).saturationModifier(0f).alwaysEdible()
            .statusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0), 1f)
            .statusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 300, 0), 1f)
            .build())));

    public static final Item CAT_ARMOR_PLATE = reg("cat_armor_plate", new Item(new Item.Settings()));
    public static final Item CAT_ARMOR = reg("cat_armor", new CatArmorItem(new Item.Settings().maxCount(16)));

    public static final Item RAIHAN_SPAWN_EGG = reg("raihan_spawn_egg", new SpawnEggItem(ModEntities.RAIHAN, 0xB22222, 0x222222, new Item.Settings()));
    public static final Item SAHIL_SPAWN_EGG = reg("sahil_spawn_egg", new SpawnEggItem(ModEntities.SAHIL, 0x2E8B57, 0x8B5A2B, new Item.Settings()));
    public static final Item ANMOL_SPAWN_EGG = reg("anmol_spawn_egg", new SpawnEggItem(ModEntities.ANMOL, 0x7B3FA0, 0xFFFFFF, new Item.Settings()));

    private static Item reg(String name, Item item) {
        return Registry.register(Registries.ITEM, UrMyVictim.id(name), item);
    }

    public static void init() {}
}
