package com.mrbraincells.urmyvictim;

import com.mrbraincells.urmyvictim.block.GrapeCropBlock;
import com.mrbraincells.urmyvictim.block.TobaccoCropBlock;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModBlocks {
    public static final Block GRAPE_CROP = reg("grape_crop", new GrapeCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT)));
    public static final Block TOBACCO_CROP = reg("tobacco_crop", new TobaccoCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT)));

    private static Block reg(String name, Block b) {
        return Registry.register(Registries.BLOCK, UrMyVictim.id(name), b);
    }

    public static void init() {}
}
