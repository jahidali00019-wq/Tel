package com.mrbraincells.urmyvictim;

import com.mrbraincells.urmyvictim.entity.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<RaihanEntity> RAIHAN = reg("raihan",
        FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, RaihanEntity::new).dimensions(EntityDimensions.fixed(0.6f, 1.95f)).build());
    public static final EntityType<SahilEntity> SAHIL = reg("sahil",
        FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, SahilEntity::new).dimensions(EntityDimensions.fixed(0.6f, 1.95f)).build());
    public static final EntityType<AnmolEntity> ANMOL = reg("anmol",
        FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, AnmolEntity::new).dimensions(EntityDimensions.fixed(0.6f, 1.95f)).build());

    private static <T extends MobEntity> EntityType<T> reg(String name, EntityType<T> type) {
        return Registry.register(Registries.ENTITY_TYPE, UrMyVictim.id(name), type);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(RAIHAN, VictimEntity.createVictimAttributes());
        FabricDefaultAttributeRegistry.register(SAHIL, VictimEntity.createVictimAttributes());
        FabricDefaultAttributeRegistry.register(ANMOL, AnmolEntity.createAnmolAttributes());
    }
}
