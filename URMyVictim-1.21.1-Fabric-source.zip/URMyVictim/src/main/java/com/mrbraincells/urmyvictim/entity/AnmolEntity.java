package com.mrbraincells.urmyvictim.entity;

import com.mrbraincells.urmyvictim.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.World;

/** Cat-loving trader. Only source of Cat Armor Plates. */
public class AnmolEntity extends MerchantEntity {
    public AnmolEntity(EntityType<? extends AnmolEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAnmolAttributes() {
        return MobEntity.createMobAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 200.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.5);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new StopFollowingCustomerGoal(this));
        this.goalSelector.add(1, new LookAtCustomerGoal(this));
        this.goalSelector.add(4, new WanderAroundFarGoal(this, 0.5));
        this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(6, new LookAroundGoal(this));
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (this.isAlive() && !this.hasCustomer() && !this.isBaby()) {
            if (hand == Hand.MAIN_HAND) player.incrementStat(Stats.TALKED_TO_VILLAGER);
            if (!this.getWorld().isClient) {
                if (!this.getOffers().isEmpty()) {
                    this.setCustomer(player);
                    this.sendOffers(player, this.getDisplayName(), 1);
                }
            }
            return ActionResult.success(this.getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    protected void fillRecipes() {
        TradeOfferList offers = this.getOffers();
        // Cat spawn eggs for gold / diamond / netherite
        offers.add(new TradeOffer(new TradedItem(Items.GOLD_INGOT, 6), new ItemStack(Items.CAT_SPAWN_EGG), 8, 5, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.DIAMOND, 2), new ItemStack(Items.CAT_SPAWN_EGG), 8, 8, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.NETHERITE_SCRAP, 1), new ItemStack(Items.CAT_SPAWN_EGG, 2), 6, 10, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.NETHERITE_INGOT, 1), new ItemStack(Items.CAT_SPAWN_EGG, 5), 4, 15, 0.05f));
        // Cat armour plates - only obtainable here
        offers.add(new TradeOffer(new TradedItem(Items.DIAMOND, 3), new ItemStack(ModItems.CAT_ARMOR_PLATE, 1), 8, 10, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.GOLD_INGOT, 10), new ItemStack(ModItems.CAT_ARMOR_PLATE, 1), 8, 8, 0.05f));
        offers.add(new TradeOffer(new TradedItem(Items.NETHERITE_SCRAP, 2), new ItemStack(ModItems.CAT_ARMOR_PLATE, 3), 4, 15, 0.05f));
        // Cat treats
        offers.add(new TradeOffer(new TradedItem(Items.EMERALD, 1), new ItemStack(Items.COD, 8), 16, 2, 0.05f));
    }

    @Override
    protected void afterUsing(TradeOffer offer) {
        if (offer.shouldRewardPlayerExperience()) {
            int xp = 3 + this.random.nextInt(4);
            this.getWorld().spawnEntity(new ExperienceOrbEntity(this.getWorld(), this.getX(), this.getY() + 0.5, this.getZ(), xp));
        }
    }

    public boolean isLeveledMerchant() {
        return false;
    }

    public SoundEvent getYesSound() {
        return SoundEvents.ENTITY_CAT_PURR;
    }

    @Override
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }
}
