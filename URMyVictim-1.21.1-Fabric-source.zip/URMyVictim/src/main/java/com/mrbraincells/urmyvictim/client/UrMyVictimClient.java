package com.mrbraincells.urmyvictim.client;

import com.mrbraincells.urmyvictim.ModBlocks;
import com.mrbraincells.urmyvictim.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;

public class UrMyVictimClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.RAIHAN, ctx -> new VictimRenderer<>(ctx, "raihan"));
        EntityRendererRegistry.register(ModEntities.SAHIL, ctx -> new VictimRenderer<>(ctx, "sahil"));
        EntityRendererRegistry.register(ModEntities.ANMOL, ctx -> new VictimRenderer<>(ctx, "anmol"));
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.GRAPE_CROP, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.TOBACCO_CROP, RenderLayer.getCutout());
    }
}
