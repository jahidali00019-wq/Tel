package com.mrbraincells.urmyvictim;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;

public class UrMyVictim implements ModInitializer {
    public static final String MOD_ID = "urmyvictim";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModEntities.init();
        ModItems.init();

        ItemGroup group = FabricItemGroup.builder()
            .displayName(Text.translatable("itemGroup.urmyvictim"))
            .icon(() -> new ItemStack(ModItems.DESHI_WINE))
            .entries((ctx, e) -> {
                e.add(ModItems.DESHI_WINE);
                e.add(ModItems.CIGARETTE);
                e.add(ModItems.GRAPES);
                e.add(ModItems.GRAPE_SEEDS);
                e.add(ModItems.TOBACCO_SEEDS);
                e.add(ModItems.TOBACCO_LEAF);
                e.add(ModItems.DRIED_TOBACCO_LEAF);
                e.add(ModItems.CAT_ARMOR_PLATE);
                e.add(ModItems.CAT_ARMOR);
                e.add(ModItems.RAIHAN_SPAWN_EGG);
                e.add(ModItems.SAHIL_SPAWN_EGG);
                e.add(ModItems.ANMOL_SPAWN_EGG);
            }).build();
        Registry.register(Registries.ITEM_GROUP, id("main"), group);

        // Wild grapes in jungles
        BiomeModifications.addFeature(
            BiomeSelectors.includeByKey(BiomeKeys.JUNGLE, BiomeKeys.SPARSE_JUNGLE, BiomeKeys.BAMBOO_JUNGLE),
            GenerationStep.Feature.VEGETAL_DECORATION,
            RegistryKey.of(RegistryKeys.PLACED_FEATURE, id("grape_patch")));

        // Natural spawns
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ModEntities.RAIHAN, 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ModEntities.SAHIL, 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.CREATURE, ModEntities.ANMOL, 2, 1, 1);
    }
}
