package com.mrbraincells.urmyvictim.client;

import com.mrbraincells.urmyvictim.UrMyVictim;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;

public class VictimRenderer<T extends MobEntity> extends BipedEntityRenderer<T, BipedEntityModel<T>> {
    private final Identifier texture;

    public VictimRenderer(EntityRendererFactory.Context ctx, String name) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.texture = Identifier.of(UrMyVictim.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}
