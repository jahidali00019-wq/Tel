package com.mrbraincells.urmyvictim.block;

import com.mojang.serialization.MapCodec;
import com.mrbraincells.urmyvictim.ModItems;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.item.ItemConvertible;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

public class TobaccoCropBlock extends CropBlock {
    public static final MapCodec<TobaccoCropBlock> CODEC = createCodec(TobaccoCropBlock::new);

    public TobaccoCropBlock(Settings settings) {
        super(settings);
    }

    @Override
    public MapCodec<TobaccoCropBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return ModItems.TOBACCO_SEEDS;
    }

    @Override
    protected boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(Blocks.FARMLAND) || floor.isIn(BlockTags.DIRT);
    }

    @Override
    public boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        return canPlantOnTop(world.getBlockState(pos.down()), world, pos.down());
    }
}
