package com.mrbraincells.urmyvictim.entity;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Cow lover: breeds and feeds cows, scares baby villagers. Fights Raihan on sight. */
public class SahilEntity extends VictimEntity {
    private static final String[] FIGHT = {
        "Oye nashedi, dhuan chhod aur sidha chal!",
        "Meri gaay ko kuch bola toh dekh lena!",
        "Raihan, tu hi toh hai jo cow ko bhi hic-hic karwata hai!",
        "Moo-ve out of my way, sharabi!",
        "Chal be, tere jaise 10 dekhe hain!",
        "Gaay meri maa jaisi hai, tu apni wine sambhal!"
    };

    public SahilEntity(EntityType<? extends VictimEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, RaihanEntity.class, true));
        this.goalSelector.add(3, new ScareBabyVillagerGoal(this));
        this.goalSelector.add(4, new TendCowsGoal(this));
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.WHEAT));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
    }

    @Override
    protected String[] fightLines() {
        return FIGHT;
    }

    /** Walks to cows, feeds babies so they grow, and breeds adults. */
    static class TendCowsGoal extends Goal {
        private final SahilEntity sahil;
        private CowEntity cow;
        private int cooldown;

        TendCowsGoal(SahilEntity s) {
            this.sahil = s;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            if (sahil.getTarget() != null) return false;
            if (cooldown > 0) { cooldown--; return false; }
            List<CowEntity> cows = sahil.getWorld().getEntitiesByClass(CowEntity.class,
                sahil.getBoundingBox().expand(16), c -> c.getBreedingAge() <= 0 && !c.isInLove());
            if (cows.isEmpty()) { cooldown = 60; return false; }
            cow = cows.stream().min(Comparator.comparingDouble(sahil::squaredDistanceTo)).get();
            return true;
        }

        @Override
        public boolean shouldContinue() {
            return cow != null && cow.isAlive() && sahil.getTarget() == null;
        }

        @Override
        public void tick() {
            sahil.getLookControl().lookAt(cow);
            if (sahil.squaredDistanceTo(cow) < 4.0) {
                sahil.swingHand(Hand.MAIN_HAND);
                if (cow.isBaby()) {
                    cow.growUp(PassiveEntity.toGrowUpAge(-cow.getBreedingAge()));
                    sahil.say("Khao khao, bade ho jao mere bacchon!");
                } else {
                    cow.setLoveTicks(600);
                    sahil.say("Aaja meri rani, ghaas khaa le. Moo!");
                }
                if (sahil.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.HEART, cow.getX(), cow.getEyeY(), cow.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
                }
                cooldown = 100;
                cow = null;
            } else {
                sahil.getNavigation().startMovingTo(cow, 1.0);
            }
        }

        @Override
        public void stop() {
            cow = null;
            sahil.getNavigation().stop();
        }
    }

    /** Runs up to baby villagers and shouts "Boo!" for fun. */
    static class ScareBabyVillagerGoal extends Goal {
        private final SahilEntity sahil;
        private VillagerEntity kid;
        private int cooldown;

        ScareBabyVillagerGoal(SahilEntity s) {
            this.sahil = s;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            if (sahil.getTarget() != null) return false;
            if (cooldown > 0) { cooldown--; return false; }
            List<VillagerEntity> kids = sahil.getWorld().getEntitiesByClass(VillagerEntity.class,
                sahil.getBoundingBox().expand(14), VillagerEntity::isBaby);
            if (kids.isEmpty()) { cooldown = 80; return false; }
            kid = kids.get(sahil.getRandom().nextInt(kids.size()));
            return true;
        }

        @Override
        public boolean shouldContinue() {
            return kid != null && kid.isAlive() && sahil.getTarget() == null;
        }

        @Override
        public void tick() {
            sahil.getLookControl().lookAt(kid);
            if (sahil.squaredDistanceTo(kid) < 6.0) {
                sahil.say("BOOOO! Hahaha, dar gaya kya chhotu?");
                double dx = kid.getX() - sahil.getX();
                double dz = kid.getZ() - sahil.getZ();
                kid.takeKnockback(0.8, -dx, -dz);
                kid.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1f, 1.4f);
                if (sahil.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(ParticleTypes.ANGRY_VILLAGER, kid.getX(), kid.getEyeY(), kid.getZ(), 4, 0.3, 0.3, 0.3, 0.0);
                }
                sahil.swingHand(Hand.MAIN_HAND);
                cooldown = 200;
                kid = null;
            } else {
                sahil.getNavigation().startMovingTo(kid, 1.1);
            }
        }

        @Override
        public void stop() {
            kid = null;
            sahil.getNavigation().stop();
        }
    }
}
