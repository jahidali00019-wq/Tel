package com.mrbraincells.urmyvictim.entity;

import com.mrbraincells.urmyvictim.ModItems;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

/** Passive, always drunk, always smoking. Fights Sahil on sight. */
public class RaihanEntity extends VictimEntity {
    private static final String[] DRUNK = {
        "Hic... tu kaun hai bhai? Tu mera bestie hai na?",
        "Ek aur peg... hic... bas ek aur!",
        "Main CEO hoon... hic... of this jungle!",
        "Dhuan nahi toh zindagi nahi, bhai!",
        "Sab ghoom raha hai... tu bhi ghoom raha hai kya?",
        "Shhh... Sahil ko mat batana main pee raha hoon.",
        "Bhai, ek cigarette hai kya? Hic!",
        "Duniya gol hai... hic... aur main bhi!",
        "Kal se pakka chhod dunga... aaj last!",
        "Tu mera dost hai ya dushman? Kuch samajh nahi aa raha."
    };
    private static final String[] FIGHT = {
        "Abe Sahil, gaay ke deewane!",
        "Chal be gwaale, teri gaay mujhe chhod!",
        "Hic... tujhe toh main dhuan mein uda dunga!",
        "Tere cows meri wine se zyada pagal hain!",
        "Aaja saale, ek haath dikhata hoon!",
        "Teri moo-moo band kar!"
    };
    private int chatCooldown = 40;

    public RaihanEntity(EntityType<? extends VictimEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, SahilEntity.class, true));
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.DESHI_WINE));
        this.equipStack(EquipmentSlot.OFFHAND, new ItemStack(ModItems.CIGARETTE));
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
        this.setEquipmentDropChance(EquipmentSlot.OFFHAND, 0f);
    }

    @Override
    protected String[] fightLines() {
        return FIGHT;
    }

    @Override
    public void tickMovement() {
        super.tickMovement();
        if (getWorld() instanceof ServerWorld sw) {
            if (age % 8 == 0) {
                sw.spawnParticles(ParticleTypes.SMOKE, getX(), getEyeY() - 0.1, getZ(), 2, 0.1, 0.05, 0.1, 0.01);
            }
            if (chatCooldown > 0) {
                chatCooldown--;
            } else if (getTarget() == null) {
                PlayerEntity p = sw.getClosestPlayer(this, 4.0);
                if (p != null) {
                    say(DRUNK[random.nextInt(DRUNK.length)]);
                    chatCooldown = 100 + random.nextInt(100);
                }
            }
        }
    }
}
