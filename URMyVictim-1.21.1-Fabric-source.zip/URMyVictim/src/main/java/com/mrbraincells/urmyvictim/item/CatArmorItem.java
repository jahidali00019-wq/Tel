package com.mrbraincells.urmyvictim.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

/** Right-click a cat to armour it (Resistance III + Absorption for 20 minutes). */
public class CatArmorItem extends Item {
    public CatArmorItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        if (entity instanceof CatEntity cat) {
            if (!user.getWorld().isClient) {
                cat.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 24000, 2));
                cat.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 24000, 2));
                cat.playSound(SoundEvents.ITEM_ARMOR_EQUIP_IRON.value(), 1f, 1f);
                if (!user.isCreative()) stack.decrement(1);
            }
            return ActionResult.success(user.getWorld().isClient);
        }
        return ActionResult.PASS;
    }
}
